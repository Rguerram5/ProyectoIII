# Markdown for Netbeans ![Description Here](https://netbeans.apache.org/images/nblogo48x48.png)

***

## Description
This plugin adds some additional features to Apache Netbeans Markdown Editor.
- Preview
- Split Window
- Suggestion
- Export to DOCX, PDF and HTML

## Tables

| Header 1 | Header 2 |  Header 3 |
|----------|----------|-----------|
|   Col 1  |   Col 2  |   Col 3   |

## Checkboxes

- [x] Option 1
- [ ] Option 2
