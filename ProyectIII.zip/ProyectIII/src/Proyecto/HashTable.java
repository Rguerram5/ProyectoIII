
package Proyecto;

import java.util.LinkedList;

public class HashTable {
    private LinkedList<String>[] table;

    public HashTable(int size) {
        table = new LinkedList[size];
        for (int i = 0; i < size; i++) {
            table[i] = new LinkedList<>();
        }
    }

    public int hash(String key) {
        int hashValue = 0;
        for (char c : key.toCharArray()) {
            hashValue = 31 * hashValue + c;
        }
        return hashValue % table.length;
    }

    public void add(String key) {
        int index = hash(key);
        table[index].add(key);
    }

    public LinkedList<String>[] getTable() {
        return table;
    }
}