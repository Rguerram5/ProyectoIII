
package Proyecto;

import java.util.ArrayList;

public class SpreadsheetModel {
    private ArrayList<Cell[][]> sheets;

    public SpreadsheetModel() {
        sheets = new ArrayList<>();
    }

    public void addSheet(int rows, int cols) {
        Cell[][] sheet = new Cell[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                sheet[i][j] = new Cell();
            }
        }
        sheets.add(sheet);
    }

    public Cell[][] getSheet(int index) {
        return sheets.get(index);
    }

    public int getSheetCount() {
        return sheets.size();
    }

    public void setCellValue(int sheetIndex, int row, int col, String value) {
        sheets.get(sheetIndex)[row][col].setValue(value);
    }

    public String getCellValue(int sheetIndex, int row, int col) {
        return sheets.get(sheetIndex)[row][col].getValue();
    }
}