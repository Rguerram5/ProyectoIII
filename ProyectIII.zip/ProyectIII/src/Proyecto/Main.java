
package Proyecto;

public class Main {
    public static void main(String[] args) {
        SpreadsheetModel model = new SpreadsheetModel();
        SpreadsheetView view = new SpreadsheetView();
        SpreadsheetController controller = new SpreadsheetController(model, view);

        view.setController(controller);
        view.setVisible(true);
    }
}