
package Proyecto;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

public class SpreadsheetView extends JFrame {
    private SpreadsheetController controller;
    private JTabbedPane tabbedPane;
    private JTextArea resultArea;
    private JTable hashTable;

    public SpreadsheetView() {
        tabbedPane = new JTabbedPane();
        resultArea = new JTextArea();
        
        setTitle("Hoja de Cálculo");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(tabbedPane, BorderLayout.CENTER);
        add(resultArea, BorderLayout.SOUTH);

        // Add menu
        JMenuBar menuBar = new JMenuBar();
        // Crear nueva opcion en menu
        // Opcion Archivo
        JMenu fileMenu = new JMenu("Archivo");
        JMenuItem hashMenuItem = new JMenuItem("Tabla hash");
        JMenuItem hashMenuItem2 = new JMenuItem("Nuevo archivo");
        hashMenuItem.addActionListener(e -> showHashTableDialog());
        hashMenuItem2.addActionListener(e -> showHashTableDialog());
        fileMenu.add(hashMenuItem);
        fileMenu.add(hashMenuItem2);
        // finaliza aca
        
        // Crear nueva opcion en menu
        // Opcion insertar
        JMenu fileInsertar = new JMenu("Insertar");
        JMenuItem hashInsertarItem = new JMenuItem("Imagenes");
        JMenuItem hashInsertarItem2 = new JMenuItem("Texto");
        fileInsertar.add(hashInsertarItem);
        fileInsertar.add(hashInsertarItem2);
        // finaliza aca
        // Crear nueva opcion en menu
        JMenu fileAyuda = new JMenu("Ayuda");
        JMenuItem hashAyudaItem = new JMenuItem("Ayuda");
        JMenuItem hashAyudaItem2 = new JMenuItem("Comentarios");
        fileAyuda.add(hashAyudaItem);
        fileAyuda.add(hashAyudaItem2);
        // Ingresan a la pestaña las opciones
        menuBar.add(fileMenu);
        menuBar.add(fileInsertar);
        menuBar.add(fileAyuda);
        setJMenuBar(menuBar);

        // Add button to add sheets
        JPanel buttonPanel = new JPanel();
        JButton addSheetButton = new JButton("Agregar Hoja");
        addSheetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String rowsStr = JOptionPane.showInputDialog("Número de filas:");
                    if (rowsStr == null) return;
                    int rows = Integer.parseInt(rowsStr);
                    
                    String colsStr = JOptionPane.showInputDialog("Número de columnas:");
                    if (colsStr == null) return;
                    int cols = Integer.parseInt(colsStr);

                    if (rows <= 0 || cols <= 0) {
                        throw new NumberFormatException();
                    }

                    controller.addSheet(rows, cols);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, introduce números enteros positivos para las filas y columnas.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        buttonPanel.add(addSheetButton);
        
        // Add buttons for operations
        JButton sumButton = new JButton("Sumar Celdas");
        sumButton.addActionListener(e -> performOperation("suma"));
        buttonPanel.add(sumButton);
        
        JButton multiplyButton = new JButton("Multiplicar Celdas");
        multiplyButton.addActionListener(e -> performOperation("multiplicación"));
        buttonPanel.add(multiplyButton);

        add(buttonPanel, BorderLayout.NORTH);
    }

    private void performOperation(String operation) {
        try {
            String sheetIndexStr = JOptionPane.showInputDialog("Índice de la hoja (empezando desde 0):");
            if (sheetIndexStr == null) return;
            int sheetIndex = Integer.parseInt(sheetIndexStr);

            String row1Str = JOptionPane.showInputDialog("Fila 1:");
            if (row1Str == null) return;
            int row1 = Integer.parseInt(row1Str);

            String col1Str = JOptionPane.showInputDialog("Columna 1:");
            if (col1Str == null) return;
            int col1 = Integer.parseInt(col1Str);

            String row2Str = JOptionPane.showInputDialog("Fila 2:");
            if (row2Str == null) return;
            int row2 = Integer.parseInt(row2Str);

            String col2Str = JOptionPane.showInputDialog("Columna 2:");
            if (col2Str == null) return;
            int col2 = Integer.parseInt(col2Str);

            if (sheetIndex < 0 || row1 < 0 || col1 < 0 || row2 < 0 || col2 < 0) {
                throw new NumberFormatException();
            }

            if ("suma".equals(operation)) {
                controller.performSum(sheetIndex, row1, col1, row2, col2);
            } else if ("multiplicación".equals(operation)) {
                controller.performMultiply(sheetIndex, row1, col1, row2, col2);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Por favor, introduce números enteros válidos.", "Error de entrada", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void setController(SpreadsheetController controller) {
        this.controller = controller;
    }

    public void updateSheets(SpreadsheetModel model) {
        tabbedPane.removeAll();
        for (int i = 0; i < model.getSheetCount(); i++) {
            Cell[][] sheet = model.getSheet(i);
            JTable table = new JTable(sheet.length, sheet[0].length);
            for (int row = 0; row < sheet.length; row++) {
                for (int col = 0; col < sheet[row].length; col++) {
                    if (sheet[row][col] != null) {
                        table.setValueAt(sheet[row][col].getValue(), row, col);
                    }
                }
            }
            tabbedPane.addTab("Sheet " + (i + 1), new JScrollPane(table));
        }
    }

    public void updateCell(int sheetIndex, int row, int col, String value) {
        JTable table = (JTable) ((JScrollPane) tabbedPane.getComponentAt(sheetIndex)).getViewport().getView();
        table.setValueAt(value, row, col);
    }

    public void displayResult(double result) {
        resultArea.setText("Resultado: " + result);
    }

    private void showHashTableDialog() {
        JDialog dialog = new JDialog(this, "Tabla Hash", true);
        dialog.setSize(400, 300);
        dialog.setLayout(new BorderLayout());

        hashTable = new JTable(10, 2);  // Tamaño de tabla arbitrario
        dialog.add(new JScrollPane(hashTable), BorderLayout.CENTER);

        JTextField inputField = new JTextField();
        JButton addButton = new JButton("Agregar");
        addButton.addActionListener(e -> {
            String key = inputField.getText();
            controller.addToHashTable(key);
        });

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(inputField, BorderLayout.CENTER);
        panel.add(addButton, BorderLayout.EAST);
        dialog.add(panel, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    public void updateHashTable(HashTable hashTable) {
        LinkedList<String>[] table = hashTable.getTable();
        for (int i = 0; i < table.length; i++) {
            StringBuilder keys = new StringBuilder();
            for (String key : table[i]) {
                keys.append(key).append(", ");
            }
            this.hashTable.setValueAt(i, i, 0);
            this.hashTable.setValueAt(keys.toString(), i, 1);
        }
    }
}