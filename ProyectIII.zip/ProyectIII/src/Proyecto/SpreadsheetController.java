
package Proyecto;


public class SpreadsheetController {
    private SpreadsheetModel model;
    private SpreadsheetView view;

    public SpreadsheetController(SpreadsheetModel model, SpreadsheetView view) {
        this.model = model;
        this.view = view;
    }

    public void addSheet(int rows, int cols) {
        model.addSheet(rows, cols);
        view.updateSheets(model);
    }

    public void performSum(int sheetIndex, int row1, int col1, int row2, int col2) {
        try {
            double value1 = Double.parseDouble(model.getCellValue(sheetIndex, row1, col1));
            double value2 = Double.parseDouble(model.getCellValue(sheetIndex, row2, col2));
            double result = value1 + value2;
            view.displayResult(result);
        } catch (NumberFormatException ex) {
            view.displayResult(Double.NaN); // Error en la operación
        }
    }

    public void performMultiply(int sheetIndex, int row1, int col1, int row2, int col2) {
        try {
            double value1 = Double.parseDouble(model.getCellValue(sheetIndex, row1, col1));
            double value2 = Double.parseDouble(model.getCellValue(sheetIndex, row2, col2));
            double result = value1 * value2;
            view.displayResult(result);
        } catch (NumberFormatException ex) {
            view.displayResult(Double.NaN); // Error en la operación
        }
    }

    public void addToHashTable(String key) {
        HashTable hashTable = new HashTable(10); // Tamaño de tabla arbitrario
        hashTable.add(key);
        view.updateHashTable(hashTable);
    }
}